Touches_GestureRecognizers

This sample app demonstrates how use UIGestureRecognizer objects to handle touch events, including multiple touches that move multiple objects.  After the application launches, three colored pieces appear onscreen that the user can move independently. A description of the app's activity is given at the top of the view.
 
Main Class
----------
MyViewController.
This view controller implements custom methods that respond to user gestures using UIGestureRecognizer objects.
It animates and moves pieces onscreen in response to touch events. 

================================================================================
Copyright (C) 2008-2013 Apple Inc. All rights reserved.
