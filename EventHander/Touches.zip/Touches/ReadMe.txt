Touches
=======

The Touches sample includes two packages.

"Touches_Responder" demonstrates how to handle touches using UIResponder's touches began, touches moved, and touches ended.

"Touches_GestureRecognizers" demonstrates how to use UIGestureRecognizers to handle touch events.

================================================================================
Copyright (C) 2008-2013 Apple Inc. All rights reserved.
