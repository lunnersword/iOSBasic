/*
Copyright (C) 2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Contains a (placard) view that can be moved by touch. Illustrates handling touch events and two styles of animation.
*/


@interface APLMoveMeView : UIView


@end

